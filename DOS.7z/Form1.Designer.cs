﻿namespace DOS
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.DosStart_Stop = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.pictureBox_previewBox = new System.Windows.Forms.PictureBox();
            this.textBox_Host = new System.Windows.Forms.TextBox();
            this.textBox_Port = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.button1 = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_previewBox)).BeginInit();
            this.SuspendLayout();
            // 
            // DosStart_Stop
            // 
            this.DosStart_Stop.Location = new System.Drawing.Point(12, 73);
            this.DosStart_Stop.Name = "DosStart_Stop";
            this.DosStart_Stop.Size = new System.Drawing.Size(51, 97);
            this.DosStart_Stop.TabIndex = 0;
            this.DosStart_Stop.Text = "Start";
            this.DosStart_Stop.UseVisualStyleBackColor = true;
            this.DosStart_Stop.Click += new System.EventHandler(this.DosStart_Stop_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 18);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(51, 15);
            this.label1.TabIndex = 1;
            this.label1.Text = "Status : ";
            // 
            // pictureBox_previewBox
            // 
            this.pictureBox_previewBox.Location = new System.Drawing.Point(87, 73);
            this.pictureBox_previewBox.Name = "pictureBox_previewBox";
            this.pictureBox_previewBox.Size = new System.Drawing.Size(190, 97);
            this.pictureBox_previewBox.TabIndex = 2;
            this.pictureBox_previewBox.TabStop = false;
            // 
            // textBox_Host
            // 
            this.textBox_Host.Location = new System.Drawing.Point(177, 15);
            this.textBox_Host.Name = "textBox_Host";
            this.textBox_Host.Size = new System.Drawing.Size(100, 23);
            this.textBox_Host.TabIndex = 3;
            this.textBox_Host.Text = "192.168.0.1";
            // 
            // textBox_Port
            // 
            this.textBox_Port.Location = new System.Drawing.Point(177, 44);
            this.textBox_Port.Name = "textBox_Port";
            this.textBox_Port.Size = new System.Drawing.Size(100, 23);
            this.textBox_Port.TabIndex = 4;
            this.textBox_Port.Text = "80";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(133, 18);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(38, 15);
            this.label2.TabIndex = 5;
            this.label2.Text = "HOST";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(134, 47);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(29, 15);
            this.label3.TabIndex = 6;
            this.label3.Text = "Port";
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(12, 36);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(116, 34);
            this.button1.TabIndex = 7;
            this.button1.Text = "Refresh";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(306, 183);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.textBox_Port);
            this.Controls.Add(this.textBox_Host);
            this.Controls.Add(this.pictureBox_previewBox);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.DosStart_Stop);
            this.Name = "Form1";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox_previewBox)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button DosStart_Stop;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.PictureBox pictureBox_previewBox;
        private System.Windows.Forms.TextBox textBox_Host;
        private System.Windows.Forms.TextBox textBox_Port;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button button1;
    }
}

